import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
export const choice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choice.url(options),
    method: 'get',
})

choice.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
choice.url = (options?: RouteQueryOptions) => {
    return choice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
choice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
choice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: choice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
    const choiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: choice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
        choiceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::choice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
        choiceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    choice.form = choiceForm
const register = {
    choice: Object.assign(choice, choice),
}

export default register