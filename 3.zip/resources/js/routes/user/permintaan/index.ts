import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/buat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::create
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/user/permintaan/simpan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/permintaan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
    const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
        showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
        showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
export const requestPrice = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestPrice.url(options),
    method: 'post',
})

requestPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan-harga',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
requestPrice.url = (options?: RouteQueryOptions) => {
    return requestPrice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
requestPrice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestPrice.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
    const requestPriceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestPrice.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
        requestPriceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestPrice.url(options),
            method: 'post',
        })
    
    requestPrice.form = requestPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
export const acceptPrice = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acceptPrice.url(args, options),
    method: 'post',
})

acceptPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/accept-price',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
acceptPrice.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return acceptPrice.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
acceptPrice.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acceptPrice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
    const acceptPriceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: acceptPrice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
        acceptPriceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: acceptPrice.url(args, options),
            method: 'post',
        })
    
    acceptPrice.form = acceptPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
export const rejectPrice = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectPrice.url(args, options),
    method: 'post',
})

rejectPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/reject-price',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
rejectPrice.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return rejectPrice.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
rejectPrice.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectPrice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
    const rejectPriceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectPrice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
        rejectPriceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectPrice.url(args, options),
            method: 'post',
        })
    
    rejectPrice.form = rejectPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
export const endService = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endService.url(args, options),
    method: 'post',
})

endService.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
endService.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return endService.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
endService.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endService.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
    const endServiceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: endService.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
        endServiceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: endService.url(args, options),
            method: 'post',
        })
    
    endService.form = endServiceForm
/**
* @see \App\Http\Controllers\User\UserController::refund
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
export const refund = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refund.url(args, options),
    method: 'post',
})

refund.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/refund',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\UserController::refund
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refund.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return refund.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::refund
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refund.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refund.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\UserController::refund
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
    const refundForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: refund.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\UserController::refund
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        refundForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: refund.url(args, options),
            method: 'post',
        })
    
    refund.form = refundForm
const permintaan = {
    create: Object.assign(create, create),
store: Object.assign(store, store),
index: Object.assign(index, index),
show: Object.assign(show, show),
requestPrice: Object.assign(requestPrice, requestPrice),
acceptPrice: Object.assign(acceptPrice, acceptPrice),
rejectPrice: Object.assign(rejectPrice, rejectPrice),
endService: Object.assign(endService, endService),
refund: Object.assign(refund, refund),
}

export default permintaan