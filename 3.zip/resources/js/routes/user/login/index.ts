import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/user/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm