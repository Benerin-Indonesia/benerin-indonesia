import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/refund',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
export const create = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/{id}/refund',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
create.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return create.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
create.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
create.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
    const createForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        createForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::create
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        createForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\User\UserController::store
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/user/permintaan/refund',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\UserController::store
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::store
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\UserController::store
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\UserController::store
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const refund = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
}

export default refund