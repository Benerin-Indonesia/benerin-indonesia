import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
export const store = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/user/chat/request/{serviceRequest}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
store.url = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { serviceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    serviceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        serviceRequest: typeof args.serviceRequest === 'object'
                ? args.serviceRequest.id
                : args.serviceRequest,
                }

    return store.definition.url
            .replace('{serviceRequest}', parsedArgs.serviceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
store.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
    const storeForm = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
        storeForm.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const chat = {
    store: Object.assign(store, store),
}

export default chat