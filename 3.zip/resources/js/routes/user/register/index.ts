import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/user/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\UserAuthController::show
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm