import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
export const success = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: success.url(options),
    method: 'post',
})

success.definition = {
    methods: ["post"],
    url: '/user/payment/success',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
success.url = (options?: RouteQueryOptions) => {
    return success.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
success.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: success.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
    const successForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: success.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
        successForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: success.url(options),
            method: 'post',
        })
    
    success.form = successForm
/**
* @see \App\Http\Controllers\User\PaymentController::pending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
export const pending = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pending.url(options),
    method: 'post',
})

pending.definition = {
    methods: ["post"],
    url: '/user/payment/pending',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::pending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
pending.url = (options?: RouteQueryOptions) => {
    return pending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::pending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
pending.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pending.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::pending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
    const pendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pending.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::pending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
        pendingForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pending.url(options),
            method: 'post',
        })
    
    pending.form = pendingForm
/**
* @see \App\Http\Controllers\User\PaymentController::fail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
export const fail = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fail.url(options),
    method: 'post',
})

fail.definition = {
    methods: ["post"],
    url: '/user/payment/fail',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::fail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
fail.url = (options?: RouteQueryOptions) => {
    return fail.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::fail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
fail.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fail.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::fail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
    const failForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: fail.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::fail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
        failForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: fail.url(options),
            method: 'post',
        })
    
    fail.form = failForm
const payment = {
    success: Object.assign(success, success),
pending: Object.assign(pending, pending),
fail: Object.assign(fail, fail),
}

export default payment