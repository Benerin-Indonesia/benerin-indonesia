import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import profile from './profile'
import permintaan from './permintaan'
import refund from './refund'
import payment44796b from './payment'
import chat from './chat'
/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/user/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/user/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
/**
 * @see routes/web.php:53
 * @route '/user/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/user/logout',
} satisfies RouteDefinition<["post"]>

/**
 * @see routes/web.php:53
 * @route '/user/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:53
 * @route '/user/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
 * @see routes/web.php:53
 * @route '/user/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
 * @see routes/web.php:53
 * @route '/user/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/user/home',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::dashboard
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/user/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
    const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
        categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categories
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
        categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categories.form = categoriesForm
/**
* @see \App\Http\Controllers\User\PaymentController::payment
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
export const payment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payment.url(options),
    method: 'post',
})

payment.definition = {
    methods: ["post"],
    url: '/user/payment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::payment
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
payment.url = (options?: RouteQueryOptions) => {
    return payment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::payment
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
payment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::payment
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
    const paymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: payment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::payment
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
        paymentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: payment.url(options),
            method: 'post',
        })
    
    payment.form = paymentForm
const user = {
    login: Object.assign(login, login),
register: Object.assign(register, register),
logout: Object.assign(logout, logout),
dashboard: Object.assign(dashboard, dashboard),
profile: Object.assign(profile, profile),
permintaan: Object.assign(permintaan, permintaan),
refund: Object.assign(refund, refund),
categories: Object.assign(categories, categories),
payment: Object.assign(payment, payment44796b),
chat: Object.assign(chat, chat),
}

export default user