import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggle
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
export const toggle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/teknisi/categories/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggle
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
toggle.url = (options?: RouteQueryOptions) => {
    return toggle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggle
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
toggle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggle
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
    const toggleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggle
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
        toggleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(options),
            method: 'post',
        })
    
    toggle.form = toggleForm
const categories = {
    toggle: Object.assign(toggle, toggle),
}

export default categories