import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import availability from './availability'
import categories from './categories'
import profile937a89 from './profile'
import withdraw from './withdraw'
import payout from './payout'
import service6abfdd from './service'
import technicianService from './technician-service'
import chat from './chat'
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/teknisi/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/teknisi/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
/**
 * @see routes/web.php:131
 * @route '/teknisi/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/teknisi/logout',
} satisfies RouteDefinition<["post"]>

/**
 * @see routes/web.php:131
 * @route '/teknisi/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:131
 * @route '/teknisi/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
 * @see routes/web.php:131
 * @route '/teknisi/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
 * @see routes/web.php:131
 * @route '/teknisi/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/teknisi/home',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::dashboard
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/teknisi/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
    const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
        profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::profile
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
        profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profile.form = profileForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
export const wallet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wallet.url(options),
    method: 'get',
})

wallet.definition = {
    methods: ["get","head"],
    url: '/teknisi/wallet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
wallet.url = (options?: RouteQueryOptions) => {
    return wallet.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
wallet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wallet.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
wallet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: wallet.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
    const walletForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: wallet.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
        walletForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: wallet.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::wallet
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
        walletForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: wallet.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    wallet.form = walletForm
/**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
export const help = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: help.url(options),
    method: 'get',
})

help.definition = {
    methods: ["get","head"],
    url: '/teknisi/bantuan',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
help.url = (options?: RouteQueryOptions) => {
    return help.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
help.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: help.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
help.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: help.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
    const helpForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: help.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
        helpForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: help.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:156
 * @route '/teknisi/bantuan'
 */
        helpForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: help.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    help.form = helpForm
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
export const service = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service.url(options),
    method: 'get',
})

service.definition = {
    methods: ["get","head"],
    url: '/teknisi/permintaan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
service.url = (options?: RouteQueryOptions) => {
    return service.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
service.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
service.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: service.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
    const serviceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: service.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
        serviceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::service
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
        serviceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    service.form = serviceForm
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
export const jadwal = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: jadwal.url(options),
    method: 'get',
})

jadwal.definition = {
    methods: ["get","head"],
    url: '/teknisi/jadwal',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
jadwal.url = (options?: RouteQueryOptions) => {
    return jadwal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
jadwal.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: jadwal.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
jadwal.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: jadwal.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
    const jadwalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: jadwal.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
        jadwalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: jadwal.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::jadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
        jadwalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: jadwal.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    jadwal.form = jadwalForm
const teknisi = {
    login: Object.assign(login, login),
register: Object.assign(register, register),
logout: Object.assign(logout, logout),
dashboard: Object.assign(dashboard, dashboard),
availability: Object.assign(availability, availability),
categories: Object.assign(categories, categories),
profile: Object.assign(profile, profile937a89),
wallet: Object.assign(wallet, wallet),
withdraw: Object.assign(withdraw, withdraw),
help: Object.assign(help, help),
payout: Object.assign(payout, payout),
service: Object.assign(service, service6abfdd),
jadwal: Object.assign(jadwal, jadwal),
technicianService: Object.assign(technicianService, technicianService),
chat: Object.assign(chat, chat),
}

export default teknisi