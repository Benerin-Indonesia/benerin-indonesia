import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teknisi/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::show
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm