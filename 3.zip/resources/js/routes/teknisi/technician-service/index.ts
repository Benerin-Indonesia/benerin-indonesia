import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
export const requestPrice = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestPrice.url(options),
    method: 'post',
})

requestPrice.definition = {
    methods: ["post"],
    url: '/teknisi/permintaan-harga',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
requestPrice.url = (options?: RouteQueryOptions) => {
    return requestPrice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
requestPrice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestPrice.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
    const requestPriceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestPrice.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::requestPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
        requestPriceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestPrice.url(options),
            method: 'post',
        })
    
    requestPrice.form = requestPriceForm
const technicianService = {
    requestPrice: Object.assign(requestPrice, requestPrice),
}

export default technicianService