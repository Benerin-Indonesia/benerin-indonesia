import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import password from './password'
import users from './users'
import technicianServices from './technician-services'
import categories from './categories'
import requests from './requests'
import payments from './payments'
import payouts from './payouts'
import balances from './balances'
/**
 * @see routes/web.php:180
 * @route '/admin'
 */
export const root = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: root.url(options),
    method: 'get',
})

root.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:180
 * @route '/admin'
 */
root.url = (options?: RouteQueryOptions) => {
    return root.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:180
 * @route '/admin'
 */
root.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: root.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:180
 * @route '/admin'
 */
root.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: root.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:180
 * @route '/admin'
 */
    const rootForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: root.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:180
 * @route '/admin'
 */
        rootForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: root.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:180
 * @route '/admin'
 */
        rootForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: root.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    root.form = rootForm
/**
* @see \App\Http\Controllers\Auth\AdminAuthController::login
 * @see app/Http/Controllers/Auth/AdminAuthController.php:17
 * @route '/admin/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/admin/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\AdminAuthController::login
 * @see app/Http/Controllers/Auth/AdminAuthController.php:17
 * @route '/admin/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AdminAuthController::login
 * @see app/Http/Controllers/Auth/AdminAuthController.php:17
 * @route '/admin/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\AdminAuthController::login
 * @see app/Http/Controllers/Auth/AdminAuthController.php:17
 * @route '/admin/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\AdminAuthController::login
 * @see app/Http/Controllers/Auth/AdminAuthController.php:17
 * @route '/admin/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:17
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
 * @see routes/web.php:219
 * @route '/admin/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/admin/logout',
} satisfies RouteDefinition<["post"]>

/**
 * @see routes/web.php:219
 * @route '/admin/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:219
 * @route '/admin/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
 * @see routes/web.php:219
 * @route '/admin/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
 * @see routes/web.php:219
 * @route '/admin/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
const admin = {
    root: Object.assign(root, root),
login: Object.assign(login, login),
password: Object.assign(password, password),
dashboard: Object.assign(dashboard, dashboard),
logout: Object.assign(logout, logout),
users: Object.assign(users, users),
technicianServices: Object.assign(technicianServices, technicianServices),
categories: Object.assign(categories, categories),
requests: Object.assign(requests, requests),
payments: Object.assign(payments, payments),
payouts: Object.assign(payouts, payouts),
balances: Object.assign(balances, balances),
}

export default admin