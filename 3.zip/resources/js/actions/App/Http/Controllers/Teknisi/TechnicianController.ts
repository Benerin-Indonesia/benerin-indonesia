import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teknisi/home',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::index
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:16
 * @route '/teknisi/home'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleAvailability
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:85
 * @route '/teknisi/availability/toggle'
 */
export const toggleAvailability = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleAvailability.url(options),
    method: 'post',
})

toggleAvailability.definition = {
    methods: ["post"],
    url: '/teknisi/availability/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleAvailability
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:85
 * @route '/teknisi/availability/toggle'
 */
toggleAvailability.url = (options?: RouteQueryOptions) => {
    return toggleAvailability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleAvailability
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:85
 * @route '/teknisi/availability/toggle'
 */
toggleAvailability.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleAvailability.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleAvailability
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:85
 * @route '/teknisi/availability/toggle'
 */
    const toggleAvailabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleAvailability.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleAvailability
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:85
 * @route '/teknisi/availability/toggle'
 */
        toggleAvailabilityForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleAvailability.url(options),
            method: 'post',
        })
    
    toggleAvailability.form = toggleAvailabilityForm
/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleCategoryStatus
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
export const toggleCategoryStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCategoryStatus.url(options),
    method: 'post',
})

toggleCategoryStatus.definition = {
    methods: ["post"],
    url: '/teknisi/categories/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleCategoryStatus
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
toggleCategoryStatus.url = (options?: RouteQueryOptions) => {
    return toggleCategoryStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleCategoryStatus
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
toggleCategoryStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCategoryStatus.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleCategoryStatus
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
    const toggleCategoryStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleCategoryStatus.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teknisi\TechnicianController::toggleCategoryStatus
 * @see app/Http/Controllers/Teknisi/TechnicianController.php:105
 * @route '/teknisi/categories/toggle-status'
 */
        toggleCategoryStatusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleCategoryStatus.url(options),
            method: 'post',
        })
    
    toggleCategoryStatus.form = toggleCategoryStatusForm
const TechnicianController = { index, toggleAvailability, toggleCategoryStatus }

export default TechnicianController