import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teknisi/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::index
 * @see app/Http/Controllers/Teknisi/ProfileController.php:22
 * @route '/teknisi/profile'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::update
 * @see app/Http/Controllers/Teknisi/ProfileController.php:47
 * @route '/teknisi/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/teknisi/profile',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::update
 * @see app/Http/Controllers/Teknisi/ProfileController.php:47
 * @route '/teknisi/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::update
 * @see app/Http/Controllers/Teknisi/ProfileController.php:47
 * @route '/teknisi/profile'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::update
 * @see app/Http/Controllers/Teknisi/ProfileController.php:47
 * @route '/teknisi/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::update
 * @see app/Http/Controllers/Teknisi/ProfileController.php:47
 * @route '/teknisi/profile'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
export const walletIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: walletIndex.url(options),
    method: 'get',
})

walletIndex.definition = {
    methods: ["get","head"],
    url: '/teknisi/wallet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
walletIndex.url = (options?: RouteQueryOptions) => {
    return walletIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
walletIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: walletIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
walletIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: walletIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
    const walletIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: walletIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
        walletIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: walletIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletIndex
 * @see app/Http/Controllers/Teknisi/ProfileController.php:109
 * @route '/teknisi/wallet'
 */
        walletIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: walletIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    walletIndex.form = walletIndexForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
export const walletWithdrawCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: walletWithdrawCreate.url(options),
    method: 'get',
})

walletWithdrawCreate.definition = {
    methods: ["get","head"],
    url: '/teknisi/withdraw/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
walletWithdrawCreate.url = (options?: RouteQueryOptions) => {
    return walletWithdrawCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
walletWithdrawCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: walletWithdrawCreate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
walletWithdrawCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: walletWithdrawCreate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
    const walletWithdrawCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: walletWithdrawCreate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
        walletWithdrawCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: walletWithdrawCreate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawCreate
 * @see app/Http/Controllers/Teknisi/ProfileController.php:132
 * @route '/teknisi/withdraw/create'
 */
        walletWithdrawCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: walletWithdrawCreate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    walletWithdrawCreate.form = walletWithdrawCreateForm
/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawStore
 * @see app/Http/Controllers/Teknisi/ProfileController.php:154
 * @route '/teknisi/withdraw'
 */
export const walletWithdrawStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: walletWithdrawStore.url(options),
    method: 'post',
})

walletWithdrawStore.definition = {
    methods: ["post"],
    url: '/teknisi/withdraw',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawStore
 * @see app/Http/Controllers/Teknisi/ProfileController.php:154
 * @route '/teknisi/withdraw'
 */
walletWithdrawStore.url = (options?: RouteQueryOptions) => {
    return walletWithdrawStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawStore
 * @see app/Http/Controllers/Teknisi/ProfileController.php:154
 * @route '/teknisi/withdraw'
 */
walletWithdrawStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: walletWithdrawStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawStore
 * @see app/Http/Controllers/Teknisi/ProfileController.php:154
 * @route '/teknisi/withdraw'
 */
    const walletWithdrawStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: walletWithdrawStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Teknisi\ProfileController::walletWithdrawStore
 * @see app/Http/Controllers/Teknisi/ProfileController.php:154
 * @route '/teknisi/withdraw'
 */
        walletWithdrawStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: walletWithdrawStore.url(options),
            method: 'post',
        })
    
    walletWithdrawStore.form = walletWithdrawStoreForm
const ProfileController = { index, update, walletIndex, walletWithdrawCreate, walletWithdrawStore }

export default ProfileController