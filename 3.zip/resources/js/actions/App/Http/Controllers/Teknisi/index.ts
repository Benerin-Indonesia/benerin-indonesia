import TechnicianController from './TechnicianController'
import ProfileController from './ProfileController'
import PayoutController from './PayoutController'
const Teknisi = {
    TechnicianController: Object.assign(TechnicianController, TechnicianController),
ProfileController: Object.assign(ProfileController, ProfileController),
PayoutController: Object.assign(PayoutController, PayoutController),
}

export default Teknisi