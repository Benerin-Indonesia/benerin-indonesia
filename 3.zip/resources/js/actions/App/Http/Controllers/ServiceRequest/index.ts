import User from './User'
import Teknisi from './Teknisi'
const ServiceRequest = {
    User: Object.assign(User, User),
Teknisi: Object.assign(Teknisi, Teknisi),
}

export default ServiceRequest