import ServiceRequestController from './ServiceRequestController'
const User = {
    ServiceRequestController: Object.assign(ServiceRequestController, ServiceRequestController),
}

export default User