import ServiceRequestController from './ServiceRequestController'
const Teknisi = {
    ServiceRequestController: Object.assign(ServiceRequestController, ServiceRequestController),
}

export default Teknisi