import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
export const buatPermintaan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buatPermintaan.url(options),
    method: 'get',
})

buatPermintaan.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/buat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
buatPermintaan.url = (options?: RouteQueryOptions) => {
    return buatPermintaan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
buatPermintaan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buatPermintaan.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
buatPermintaan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: buatPermintaan.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
    const buatPermintaanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: buatPermintaan.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
        buatPermintaanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: buatPermintaan.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::buatPermintaan
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:92
 * @route '/user/permintaan/buat'
 */
        buatPermintaanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: buatPermintaan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    buatPermintaan.form = buatPermintaanForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/user/permintaan/simpan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::store
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:155
 * @route '/user/permintaan/simpan'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/permintaan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:28
 * @route '/user/permintaan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
    const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
        showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:121
 * @route '/user/permintaan/{id}'
 */
        showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
export const createPrice = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPrice.url(options),
    method: 'post',
})

createPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan-harga',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
createPrice.url = (options?: RouteQueryOptions) => {
    return createPrice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
createPrice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPrice.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
    const createPriceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createPrice.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:0
 * @route '/user/permintaan-harga'
 */
        createPriceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createPrice.url(options),
            method: 'post',
        })
    
    createPrice.form = createPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
export const acceptPrice = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acceptPrice.url(args, options),
    method: 'post',
})

acceptPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/accept-price',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
acceptPrice.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return acceptPrice.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
acceptPrice.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acceptPrice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
    const acceptPriceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: acceptPrice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::acceptPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:103
 * @route '/user/permintaan/{id}/accept-price'
 */
        acceptPriceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: acceptPrice.url(args, options),
            method: 'post',
        })
    
    acceptPrice.form = acceptPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
export const rejectPrice = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectPrice.url(args, options),
    method: 'post',
})

rejectPrice.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/reject-price',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
rejectPrice.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return rejectPrice.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
rejectPrice.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectPrice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
    const rejectPriceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectPrice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::rejectPrice
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:208
 * @route '/user/permintaan/{id}/reject-price'
 */
        rejectPriceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectPrice.url(args, options),
            method: 'post',
        })
    
    rejectPrice.form = rejectPriceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
export const endService = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endService.url(args, options),
    method: 'post',
})

endService.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
endService.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return endService.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
endService.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endService.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
    const endServiceForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: endService.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::endService
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:229
 * @route '/user/permintaan/{id}/end'
 */
        endServiceForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: endService.url(args, options),
            method: 'post',
        })
    
    endService.form = endServiceForm
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
export const categoriesIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categoriesIndex.url(options),
    method: 'get',
})

categoriesIndex.definition = {
    methods: ["get","head"],
    url: '/user/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categoriesIndex.url = (options?: RouteQueryOptions) => {
    return categoriesIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categoriesIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categoriesIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
categoriesIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categoriesIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
    const categoriesIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categoriesIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
        categoriesIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categoriesIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\User\ServiceRequestController::categoriesIndex
 * @see app/Http/Controllers/ServiceRequest/User/ServiceRequestController.php:71
 * @route '/user/categories'
 */
        categoriesIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categoriesIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categoriesIndex.form = categoriesIndexForm
const ServiceRequestController = { buatPermintaan, store, index, show, createPrice, acceptPrice, rejectPrice, endService, categoriesIndex }

export default ServiceRequestController