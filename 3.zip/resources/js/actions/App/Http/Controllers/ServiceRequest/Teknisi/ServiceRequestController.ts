import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/teknisi/permintaan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::index
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:19
 * @route '/teknisi/permintaan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
export const indexJadwal = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexJadwal.url(options),
    method: 'get',
})

indexJadwal.definition = {
    methods: ["get","head"],
    url: '/teknisi/jadwal',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
indexJadwal.url = (options?: RouteQueryOptions) => {
    return indexJadwal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
indexJadwal.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexJadwal.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
indexJadwal.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexJadwal.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
    const indexJadwalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexJadwal.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
        indexJadwalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexJadwal.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::indexJadwal
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:82
 * @route '/teknisi/jadwal'
 */
        indexJadwalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexJadwal.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexJadwal.form = indexJadwalForm
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/teknisi/permintaan/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
    const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
        showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::show
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:126
 * @route '/teknisi/permintaan/{id}'
 */
        showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
export const createPrice = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPrice.url(options),
    method: 'post',
})

createPrice.definition = {
    methods: ["post"],
    url: '/teknisi/permintaan-harga',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
createPrice.url = (options?: RouteQueryOptions) => {
    return createPrice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
createPrice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPrice.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
    const createPriceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createPrice.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ServiceRequest\Teknisi\ServiceRequestController::createPrice
 * @see app/Http/Controllers/ServiceRequest/Teknisi/ServiceRequestController.php:156
 * @route '/teknisi/permintaan-harga'
 */
        createPriceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createPrice.url(options),
            method: 'post',
        })
    
    createPrice.form = createPriceForm
const ServiceRequestController = { index, indexJadwal, show, createPrice }

export default ServiceRequestController