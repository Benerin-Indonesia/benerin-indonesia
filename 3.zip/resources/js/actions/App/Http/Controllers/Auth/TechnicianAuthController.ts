import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
export const showLoginForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginForm.url(options),
    method: 'get',
})

showLoginForm.definition = {
    methods: ["get","head"],
    url: '/teknisi/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
showLoginForm.url = (options?: RouteQueryOptions) => {
    return showLoginForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
showLoginForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
showLoginForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showLoginForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
    const showLoginFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showLoginForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
        showLoginFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:15
 * @route '/teknisi/login'
 */
        showLoginFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showLoginForm.form = showLoginFormForm
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/teknisi/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::login
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:20
 * @route '/teknisi/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
export const showRegisterForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterForm.url(options),
    method: 'get',
})

showRegisterForm.definition = {
    methods: ["get","head"],
    url: '/teknisi/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
showRegisterForm.url = (options?: RouteQueryOptions) => {
    return showRegisterForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
showRegisterForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
showRegisterForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRegisterForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
    const showRegisterFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showRegisterForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
        showRegisterFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:41
 * @route '/teknisi/register'
 */
        showRegisterFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showRegisterForm.form = showRegisterFormForm
/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/teknisi/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\TechnicianAuthController::register
 * @see app/Http/Controllers/Auth/TechnicianAuthController.php:46
 * @route '/teknisi/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
const TechnicianAuthController = { showLoginForm, login, showRegisterForm, register }

export default TechnicianAuthController