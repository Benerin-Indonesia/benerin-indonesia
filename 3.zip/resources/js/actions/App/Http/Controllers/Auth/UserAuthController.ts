import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
export const showLoginForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginForm.url(options),
    method: 'get',
})

showLoginForm.definition = {
    methods: ["get","head"],
    url: '/user/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
showLoginForm.url = (options?: RouteQueryOptions) => {
    return showLoginForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
showLoginForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
showLoginForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showLoginForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
    const showLoginFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showLoginForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
        showLoginFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\UserAuthController::showLoginForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:15
 * @route '/user/login'
 */
        showLoginFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showLoginForm.form = showLoginFormForm
/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/user/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::login
 * @see app/Http/Controllers/Auth/UserAuthController.php:20
 * @route '/user/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
export const showRegisterForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterForm.url(options),
    method: 'get',
})

showRegisterForm.definition = {
    methods: ["get","head"],
    url: '/user/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
showRegisterForm.url = (options?: RouteQueryOptions) => {
    return showRegisterForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
showRegisterForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
showRegisterForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRegisterForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
    const showRegisterFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showRegisterForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
        showRegisterFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\UserAuthController::showRegisterForm
 * @see app/Http/Controllers/Auth/UserAuthController.php:42
 * @route '/user/register'
 */
        showRegisterFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showRegisterForm.form = showRegisterFormForm
/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/user/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\UserAuthController::register
 * @see app/Http/Controllers/Auth/UserAuthController.php:47
 * @route '/user/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
const UserAuthController = { showLoginForm, login, showRegisterForm, register }

export default UserAuthController