import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
export const showLoginChoice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginChoice.url(options),
    method: 'get',
})

showLoginChoice.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
showLoginChoice.url = (options?: RouteQueryOptions) => {
    return showLoginChoice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
showLoginChoice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLoginChoice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
showLoginChoice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showLoginChoice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
    const showLoginChoiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showLoginChoice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
        showLoginChoiceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginChoice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showLoginChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:10
 * @route '/login'
 */
        showLoginChoiceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showLoginChoice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showLoginChoice.form = showLoginChoiceForm
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
export const showRegisterChoice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterChoice.url(options),
    method: 'get',
})

showRegisterChoice.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
showRegisterChoice.url = (options?: RouteQueryOptions) => {
    return showRegisterChoice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
showRegisterChoice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegisterChoice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
showRegisterChoice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRegisterChoice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
    const showRegisterChoiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showRegisterChoice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
        showRegisterChoiceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterChoice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\PublicAuthController::showRegisterChoice
 * @see app/Http/Controllers/Auth/PublicAuthController.php:15
 * @route '/register'
 */
        showRegisterChoiceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegisterChoice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showRegisterChoice.form = showRegisterChoiceForm
const PublicAuthController = { showLoginChoice, showRegisterChoice }

export default PublicAuthController