import PublicAuthController from './PublicAuthController'
import UserAuthController from './UserAuthController'
import TechnicianAuthController from './TechnicianAuthController'
import AdminAuthController from './AdminAuthController'
const Auth = {
    PublicAuthController: Object.assign(PublicAuthController, PublicAuthController),
UserAuthController: Object.assign(UserAuthController, UserAuthController),
TechnicianAuthController: Object.assign(TechnicianAuthController, TechnicianAuthController),
AdminAuthController: Object.assign(AdminAuthController, AdminAuthController),
}

export default Auth