import Auth from './Auth'
import DashboardController from './DashboardController'
import UserController from './UserController'
import TechnicianServiceController from './TechnicianServiceController'
import CategoryController from './CategoryController'
import ServiceRequestController from './ServiceRequestController'
import PaymentController from './PaymentController'
import PayoutController from './PayoutController'
import BalanceController from './BalanceController'
const Admin = {
    Auth: Object.assign(Auth, Auth),
DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
TechnicianServiceController: Object.assign(TechnicianServiceController, TechnicianServiceController),
CategoryController: Object.assign(CategoryController, CategoryController),
ServiceRequestController: Object.assign(ServiceRequestController, ServiceRequestController),
PaymentController: Object.assign(PaymentController, PaymentController),
PayoutController: Object.assign(PayoutController, PayoutController),
BalanceController: Object.assign(BalanceController, BalanceController),
}

export default Admin