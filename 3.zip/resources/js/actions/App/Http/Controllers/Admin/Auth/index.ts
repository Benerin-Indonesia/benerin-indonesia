import AdminPasswordResetLinkController from './AdminPasswordResetLinkController'
import AdminNewPasswordController from './AdminNewPasswordController'
const Auth = {
    AdminPasswordResetLinkController: Object.assign(AdminPasswordResetLinkController, AdminPasswordResetLinkController),
AdminNewPasswordController: Object.assign(AdminNewPasswordController, AdminNewPasswordController),
}

export default Auth