import ChatMessageController from './ChatMessageController'
const Chat = {
    ChatMessageController: Object.assign(ChatMessageController, ChatMessageController),
}

export default Chat