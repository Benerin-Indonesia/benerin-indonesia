import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
const store3ed533165d0a3de28c06904bceb7c547 = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store3ed533165d0a3de28c06904bceb7c547.url(args, options),
    method: 'post',
})

store3ed533165d0a3de28c06904bceb7c547.definition = {
    methods: ["post"],
    url: '/user/chat/request/{serviceRequest}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
store3ed533165d0a3de28c06904bceb7c547.url = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { serviceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    serviceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        serviceRequest: typeof args.serviceRequest === 'object'
                ? args.serviceRequest.id
                : args.serviceRequest,
                }

    return store3ed533165d0a3de28c06904bceb7c547.definition.url
            .replace('{serviceRequest}', parsedArgs.serviceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
store3ed533165d0a3de28c06904bceb7c547.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store3ed533165d0a3de28c06904bceb7c547.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
    const store3ed533165d0a3de28c06904bceb7c547Form = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store3ed533165d0a3de28c06904bceb7c547.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/user/chat/request/{serviceRequest}'
 */
        store3ed533165d0a3de28c06904bceb7c547Form.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store3ed533165d0a3de28c06904bceb7c547.url(args, options),
            method: 'post',
        })
    
    store3ed533165d0a3de28c06904bceb7c547.form = store3ed533165d0a3de28c06904bceb7c547Form
    /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/teknisi/chat/request/{serviceRequest}'
 */
const store5bd9f96046fa5eb97fa8939daac75234 = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store5bd9f96046fa5eb97fa8939daac75234.url(args, options),
    method: 'post',
})

store5bd9f96046fa5eb97fa8939daac75234.definition = {
    methods: ["post"],
    url: '/teknisi/chat/request/{serviceRequest}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/teknisi/chat/request/{serviceRequest}'
 */
store5bd9f96046fa5eb97fa8939daac75234.url = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { serviceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    serviceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        serviceRequest: typeof args.serviceRequest === 'object'
                ? args.serviceRequest.id
                : args.serviceRequest,
                }

    return store5bd9f96046fa5eb97fa8939daac75234.definition.url
            .replace('{serviceRequest}', parsedArgs.serviceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/teknisi/chat/request/{serviceRequest}'
 */
store5bd9f96046fa5eb97fa8939daac75234.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store5bd9f96046fa5eb97fa8939daac75234.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/teknisi/chat/request/{serviceRequest}'
 */
    const store5bd9f96046fa5eb97fa8939daac75234Form = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store5bd9f96046fa5eb97fa8939daac75234.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Chat\ChatMessageController::store
 * @see app/Http/Controllers/Chat/ChatMessageController.php:18
 * @route '/teknisi/chat/request/{serviceRequest}'
 */
        store5bd9f96046fa5eb97fa8939daac75234Form.post = (args: { serviceRequest: number | { id: number } } | [serviceRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store5bd9f96046fa5eb97fa8939daac75234.url(args, options),
            method: 'post',
        })
    
    store5bd9f96046fa5eb97fa8939daac75234.form = store5bd9f96046fa5eb97fa8939daac75234Form

export const store = {
    '/user/chat/request/{serviceRequest}': store3ed533165d0a3de28c06904bceb7c547,
    '/teknisi/chat/request/{serviceRequest}': store5bd9f96046fa5eb97fa8939daac75234,
}

const ChatMessageController = { store }

export default ChatMessageController