import Auth from './Auth'
import LandingPageController from './LandingPageController'
import User from './User'
import ServiceRequest from './ServiceRequest'
import Chat from './Chat'
import Teknisi from './Teknisi'
import Admin from './Admin'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
LandingPageController: Object.assign(LandingPageController, LandingPageController),
User: Object.assign(User, User),
ServiceRequest: Object.assign(ServiceRequest, ServiceRequest),
Chat: Object.assign(Chat, Chat),
Teknisi: Object.assign(Teknisi, Teknisi),
Admin: Object.assign(Admin, Admin),
}

export default Controllers