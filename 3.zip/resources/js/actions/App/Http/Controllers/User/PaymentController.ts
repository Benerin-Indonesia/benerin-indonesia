import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\PaymentController::paymentHandler
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
export const paymentHandler = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentHandler.url(options),
    method: 'post',
})

paymentHandler.definition = {
    methods: ["post"],
    url: '/user/payment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::paymentHandler
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
paymentHandler.url = (options?: RouteQueryOptions) => {
    return paymentHandler.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::paymentHandler
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
paymentHandler.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentHandler.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::paymentHandler
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
    const paymentHandlerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paymentHandler.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::paymentHandler
 * @see app/Http/Controllers/User/PaymentController.php:28
 * @route '/user/payment'
 */
        paymentHandlerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paymentHandler.url(options),
            method: 'post',
        })
    
    paymentHandler.form = paymentHandlerForm
/**
* @see \App\Http\Controllers\User\PaymentController::paymentSuccess
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
export const paymentSuccess = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentSuccess.url(options),
    method: 'post',
})

paymentSuccess.definition = {
    methods: ["post"],
    url: '/user/payment/success',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::paymentSuccess
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
paymentSuccess.url = (options?: RouteQueryOptions) => {
    return paymentSuccess.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::paymentSuccess
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
paymentSuccess.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentSuccess.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::paymentSuccess
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
    const paymentSuccessForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paymentSuccess.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::paymentSuccess
 * @see app/Http/Controllers/User/PaymentController.php:88
 * @route '/user/payment/success'
 */
        paymentSuccessForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paymentSuccess.url(options),
            method: 'post',
        })
    
    paymentSuccess.form = paymentSuccessForm
/**
* @see \App\Http\Controllers\User\PaymentController::paymentPending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
export const paymentPending = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentPending.url(options),
    method: 'post',
})

paymentPending.definition = {
    methods: ["post"],
    url: '/user/payment/pending',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::paymentPending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
paymentPending.url = (options?: RouteQueryOptions) => {
    return paymentPending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::paymentPending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
paymentPending.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentPending.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::paymentPending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
    const paymentPendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paymentPending.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::paymentPending
 * @see app/Http/Controllers/User/PaymentController.php:100
 * @route '/user/payment/pending'
 */
        paymentPendingForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paymentPending.url(options),
            method: 'post',
        })
    
    paymentPending.form = paymentPendingForm
/**
* @see \App\Http\Controllers\User\PaymentController::paymentFail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
export const paymentFail = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentFail.url(options),
    method: 'post',
})

paymentFail.definition = {
    methods: ["post"],
    url: '/user/payment/fail',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::paymentFail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
paymentFail.url = (options?: RouteQueryOptions) => {
    return paymentFail.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::paymentFail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
paymentFail.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: paymentFail.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::paymentFail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
    const paymentFailForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: paymentFail.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::paymentFail
 * @see app/Http/Controllers/User/PaymentController.php:112
 * @route '/user/payment/fail'
 */
        paymentFailForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: paymentFail.url(options),
            method: 'post',
        })
    
    paymentFail.form = paymentFailForm
const PaymentController = { paymentHandler, paymentSuccess, paymentPending, paymentFail }

export default PaymentController