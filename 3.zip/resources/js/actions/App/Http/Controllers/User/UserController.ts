import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/home',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::index
 * @see app/Http/Controllers/User/UserController.php:16
 * @route '/user/home'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
export const refundIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: refundIndex.url(options),
    method: 'get',
})

refundIndex.definition = {
    methods: ["get","head"],
    url: '/user/refund',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
refundIndex.url = (options?: RouteQueryOptions) => {
    return refundIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
refundIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: refundIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
refundIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: refundIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
    const refundIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: refundIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
        refundIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: refundIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::refundIndex
 * @see app/Http/Controllers/User/UserController.php:64
 * @route '/user/refund'
 */
        refundIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: refundIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    refundIndex.form = refundIndexForm
/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
const refundCreate6f124ba917de348178ce909c25cd54ec = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
    method: 'get',
})

refundCreate6f124ba917de348178ce909c25cd54ec.definition = {
    methods: ["get","head"],
    url: '/user/permintaan/{id}/refund',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refundCreate6f124ba917de348178ce909c25cd54ec.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return refundCreate6f124ba917de348178ce909c25cd54ec.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refundCreate6f124ba917de348178ce909c25cd54ec.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refundCreate6f124ba917de348178ce909c25cd54ec.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
    const refundCreate6f124ba917de348178ce909c25cd54ecForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        refundCreate6f124ba917de348178ce909c25cd54ecForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        refundCreate6f124ba917de348178ce909c25cd54ecForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    refundCreate6f124ba917de348178ce909c25cd54ec.form = refundCreate6f124ba917de348178ce909c25cd54ecForm
    /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
const refundCreate6f124ba917de348178ce909c25cd54ec = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
    method: 'post',
})

refundCreate6f124ba917de348178ce909c25cd54ec.definition = {
    methods: ["post"],
    url: '/user/permintaan/{id}/refund',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refundCreate6f124ba917de348178ce909c25cd54ec.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return refundCreate6f124ba917de348178ce909c25cd54ec.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
refundCreate6f124ba917de348178ce909c25cd54ec.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
    const refundCreate6f124ba917de348178ce909c25cd54ecForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\UserController::refundCreate
 * @see app/Http/Controllers/User/UserController.php:113
 * @route '/user/permintaan/{id}/refund'
 */
        refundCreate6f124ba917de348178ce909c25cd54ecForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: refundCreate6f124ba917de348178ce909c25cd54ec.url(args, options),
            method: 'post',
        })
    
    refundCreate6f124ba917de348178ce909c25cd54ec.form = refundCreate6f124ba917de348178ce909c25cd54ecForm

export const refundCreate = {
    '/user/permintaan/{id}/refund': refundCreate6f124ba917de348178ce909c25cd54ec,
    '/user/permintaan/{id}/refund': refundCreate6f124ba917de348178ce909c25cd54ec,
}

/**
* @see \App\Http\Controllers\User\UserController::refundStore
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
export const refundStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refundStore.url(options),
    method: 'post',
})

refundStore.definition = {
    methods: ["post"],
    url: '/user/permintaan/refund',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\UserController::refundStore
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
refundStore.url = (options?: RouteQueryOptions) => {
    return refundStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\UserController::refundStore
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
refundStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refundStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\UserController::refundStore
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
    const refundStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: refundStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\UserController::refundStore
 * @see app/Http/Controllers/User/UserController.php:155
 * @route '/user/permintaan/refund'
 */
        refundStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: refundStore.url(options),
            method: 'post',
        })
    
    refundStore.form = refundStoreForm
const UserController = { index, refundIndex, refundCreate, refundStore }

export default UserController