import UserController from './UserController'
import ProfileController from './ProfileController'
import PaymentController from './PaymentController'
const User = {
    UserController: Object.assign(UserController, UserController),
ProfileController: Object.assign(ProfileController, ProfileController),
PaymentController: Object.assign(PaymentController, PaymentController),
}

export default User